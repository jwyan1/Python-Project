from django.db import models

# Creating a class model that will pass to the db file.
class djangoClasses(models.Model):
    title = models.CharField(max_length=60)
    instructor = models.CharField(max_length=60)
    course_no = models.DecimalField(default=0.00, max_digits=10000, decimal_places=2)
    duration = models.FloatField()

    objects = models.Manager()

# using init with self to create a string of the cooresponding title instead of calling it
# an object.
    def __str__(self):
        return self.title