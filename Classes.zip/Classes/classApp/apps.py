from django.apps import AppConfig

# setting up the app config for "classApp"
class ClassappConfig(AppConfig):
    name = 'classApp'
